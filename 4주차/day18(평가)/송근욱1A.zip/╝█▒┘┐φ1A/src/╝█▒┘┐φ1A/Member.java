package 송근욱1A;

public abstract class Member {
	private String id;
	private String pw;
	private String name;
	
	public Member(String id, String pw, String name) {
		this.id = id;
		this.pw = pw;
		this.name = name;
		
		/* 멤버 테스트 */
//		System.out.println("\n\tMember 생성자 테스트");
//		System.out.printf("%s]아이디 : %s, 비번 : %s%n\n", name, id, pw);
	}
	
	public abstract String toString();
	
	public String getId() {
		return id;
	}
	public String getPw() {
		return pw;
	}
	public String getName() {
		return name;
	}
}

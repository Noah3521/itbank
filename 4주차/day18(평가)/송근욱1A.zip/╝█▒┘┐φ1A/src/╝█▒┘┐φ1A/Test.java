package 송근욱1A;

public class Test {
	public static void main(String[] args) {

		int row = 0;
		Member[] arr = null;
		String id;
		Member member = null;

		/* === Member === */
		System.out.println("\n\tmember생성 테스트\n");

		// 판매자 테스트
		Seller seller1 = new Seller("seller1", "1234", "홍길동", "CU");
		System.out.println(seller1);

		// 구매자 테스트
		Customer customer1 = new Customer("customer1", "1234", "짱구", "떡잎마을");
		System.out.println(customer1);

		/* === Handler === */
		System.out.println("\n\thandler 테스트\n");

		Handler handler = new Handler();

		/* === 회원가입 === */
		System.out.println("\n\t회원가입 테스트\n");
		row = handler.insert(seller1);
		System.out.println(row + "개 입력 성공!\n");
		row = handler.insert(customer1);
		System.out.println(row + "개 입력 성공!\n");

		// 전체 출력
		arr = handler.selectAll();
		for (Member acc : arr) {
			if (acc != null) {
				System.out.println(acc);
			}
		}

		/* === 3) 회원탈퇴 === */
		System.out.println("\n\t회원탈퇴 테스트\n");

		// 3 - 1) 성공 시
		id = "seller1";
		row = handler.delete(id);
		System.out.println(row + "개 제거 성공!\n");

		// 3 - 2) 실패 시
		id = "asdf";
		row = handler.delete(id);
		System.out.println(row + "개 제거 성공!\n");

		// 전체 출력
		arr = handler.selectAll();
		for (Member acc : arr) {
			if (acc != null) {
				System.out.println(acc);
			}
		}

		/* === 4) 단일 검색 === */
		System.out.println("\n\t단일검색 테스트\n");

		// 4 - 1) 성공 시
		id = "customer1";
		member = handler.selectOne(id);
		System.out.println(member != null ? "\n\t검색한 데이터\n\n" + member : "검색한 데이터가 존재하지 않습니다.");

		// 4 - 2) 실패 시
		id = "asdf";
		member = handler.selectOne(id);
		System.out.println(member != null ? "\n\t검색한 데이터\n\n" + member : "검색한 데이터가 존재하지 않습니다.");

		
		/* === 5) 정렬 === */
		System.out.println("\n\t정렬 테스트\n");

		// 5 - 1) 정렬 하기 전
		System.out.println("\n\t정렬 전 배열\n");
		arr = handler.sort();
		// 전체 출력
		arr = handler.selectAll();
		for (Member acc : arr) {
			if (acc != null) {
				System.out.println(acc);
			}
		}
		
		// 5- 1) 정렬 한 후
		System.out.println("\n\t정렬 후 배열\n");
		arr = handler.sort();
		// 전체 출력
		arr = handler.selectAll();
		for (Member acc : arr) {
			if (acc != null) {
				System.out.println(acc);
			}
		}

	}
}

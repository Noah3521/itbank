package 송근욱1A;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Handler handler = new Handler();
//		Handler handler = test(); // 더미 데이터가 있는 Handler
		
		int row = 0;			// 실행에 성공한 개수
		Member[] arr = null;	// 전체 배열을 담을 공간
		String id;				// 회원가입때 id를 받을 공간 / 검색할 id
		String pw;				// 회원가입때 pw를 받을 공간
		String name;			// 회원가입때 name을 받을 공간
		Member member = null;	// 입력이나 검색에 사용할 공간
		char confirm;			// 재확인이 필요한 곳에 사용자 입력을 받을 공간
		int menu;				// 사용자 입력을 받는 menu
		
		// 처음 한번만 출력
		System.out.println();
		System.out.println("\t쇼핑몰 회원관리 프로그램 (응시자 : 송근욱)");
		
		while(true) { // menu가 0이 아니라면 반복
			/* 메뉴 입력 */
			System.out.println();
			System.out.println("1. 회원가입");
			System.out.println("2. 전체목록");
			System.out.println("3. 회원검색");
			System.out.println("4. 회원탈퇴");
			System.out.println("5. 정렬(ID↑)");
			System.out.println("0. 종료");
			System.out.print("메뉴 선택 >>> ");
			menu = Integer.parseInt(sc.nextLine());
			
			switch (menu) {
			
			case 1: // 1. 회원가입
				/* 유형 선택 */
				System.out.println();
				System.out.println("\t회원가입");
				System.out.println();
				System.out.print("회원 유형을 선택하세요 (1. 구매자 | 2. 판매자) : ");
				menu = Integer.parseInt(sc.nextLine());
				
				// menu가 유형에 없는 번호라면 
				if (menu!=1 && menu!=2) {
					System.out.println("\n\t잘못된 번호를 입력하였습니다.");
					break;
				}
				
				/* 계정 정보 입력 */
				System.out.print("ID를 입력하세요 : ");
				id = sc.nextLine();
				System.out.print("Password를 입력하세요 : ");
				pw = sc.nextLine();
				System.out.print("이름을 입력하세요 : ");
				name = sc.nextLine();
				
				/* 유형에 따른 입력 */
				if (menu==1) { 		// 구매자일때
					System.out.print("배송주소를 입력하세요 : ");
					String address = sc.nextLine();
					Customer tmp = new Customer(id, pw, name, address);
					member = tmp;
				}
				else if (menu==2) {	// 판매자일때					
					System.out.print("가게이름을 입력하세요 : ");
					String store = sc.nextLine();
					Seller tmp = new Seller(id, pw, name, store);
					member = tmp;
				}
				
				/* 해당 기능 수행 */
				row = handler.insert(member);
				
				System.out.println(row!=0 
									?
									"\n\t회원가입이 정상적으로 처리되었습니다\n" 
									:
									"\n\t이미 가입된 계정입니다");
				break;
				
			case 2: // 2. 전체목록
				arr = handler.selectAll();	// 전체 배열을 받아온다
				System.out.println();
				System.out.println("\t전체 회원 정보");
				System.out.println();
				show(arr);					// 출력한다
				break;
				
			case 3:	// 3. 회원검색
				
				/* 검색할 id 입력 */
				System.out.println();
				System.out.println("\tID로 회원을 검색합니다");
				System.out.println();
				System.out.print("검색할 ID 입력 : ");
				id = sc.nextLine();
				
				/* 해당 기능 수행 */
				member = handler.selectOne(id);   // 검색된 아이디를 받아온다, 검색되지 않았으면 null이다.
				System.out.println(member != null // null이 아니라면 계정정보를, null이라면 오류 메시지를 출력한다
								   ? 
								   member 
								   :
								   "\n\t"+id+" : 회원을 찾을 수 없습니다");
				break;
				
			case 4:	// 4. 회원탈퇴	
				
				/* 삭제할 id 입력 */
				System.out.println();
				System.out.println("\t지정한 계정을 탈퇴합니다");
				System.out.println();
				System.out.println("\tID로 회원을 검색합니다");
				System.out.println();
				System.out.print("검색할 ID 입력 : ");
				id = sc.nextLine();
				
				/* 해당 기능 수행 */
				member = handler.selectOne(id);   // 검색된 아이디를 받아온다, 검색되지 않았으면 null이다.
				if(member!=null) {	// 검색된 계정이 있을 때
					// 계정 정보 출력
					System.out.println(member);	
					System.out.println();
					
					// 탈퇴 여부 재확인
					System.out.print("정말 탈퇴하시겠습니까 (y/N) : ");
					confirm = sc.nextLine().charAt(0); // 문자열의 첫글자만 뽑아옴
					
					// 탈퇴 취소
					if (confirm=='n' || confirm=='N') {		// 입력이 n이나 N일 때
						System.out.println("\n\t회원 탈퇴를 취소하였습니다");
						break;
					}
					else if (confirm!='y' && confirm!='Y') {// 입력이 y이나 Y가 아닐 때 (확인 범위가 아닐 때)
						System.out.println("\n\t잘못된 문자를 입력하였습니다.");
						break;
					}
					
					// 탈퇴 수행
					row = handler.delete(id);
					System.out.println(row != 0 ? "\n\t"+id+" 계정이 탈퇴처리 되었습니다" : id+" 계정 탈퇴에 실패했습니다.");
				}
				else {	// 검색된 계정이 없을 때
					System.out.println("\n\t"+id+" : 회원을 찾을 수 없습니다");
				}
				
				
				break;
			
			case 5:	// 5. 정렬
				
				// 정렬한 코드를 arr에 대입
				arr = handler.sort();
				
				System.out.println();
				System.out.println("\t정렬이 완료되었습니다");
				System.out.println();
				
				// 정렬한 코드 출력
				show(arr);
				
				break;
				
			case 0:
				sc.close();
				System.out.println("\n\t프로그램을 종료합니다.");
				return;
				
			default:
				System.out.println("\n\t잘못된 번호를 입력하였습니다.");
				break;
			}	// end of switch
		}	// end of while
	}	// end of main

	/* Member배열의 값을 모두 출력하는 함수 */
	private static void show(Member[] arr) {
		for(Member member : arr) {
			if(member!=null) {
				System.out.println(member);
			}
		}
	}
	
	// 더미데이터가 포함된 Handler 반환
	@SuppressWarnings("unused")
	private static Handler test() {
		Handler hand = new Handler();
		
		hand.insert(new Seller("seller4", "it", "홍진호", "과일가게4"));
		hand.insert(new Customer("customer1", "it", "신짱구", "떡잎마을"));
		hand.insert(new Seller("seller1", "it", "임요한", "과일가게1"));
		hand.insert(new Seller("seller2", "it", "고구마", "과일가게2"));
		
		hand.insert(new Customer("customer2", "it", "한유리", "떡잎마을"));
		hand.insert(new Seller("seller3", "it", "오징어", "과일가게3"));
		hand.insert(new Customer("customer3", "it", "김철수", "떡잎마을"));
		hand.insert(new Customer("customer4", "it", "맹구", "떡잎마을"));
		
		return hand;
	}
}	

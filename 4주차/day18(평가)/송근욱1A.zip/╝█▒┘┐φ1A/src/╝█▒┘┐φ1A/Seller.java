package 송근욱1A;

public class Seller extends Member{
	private String store;
	public Seller(String id, String pw, String name, String store) {
		super(id, pw, name);
		this.store = store;
	}
	public String getStore() {
		return store;
	}
	public void setStore(String store) {
		this.store = store;
	}
	@Override
	public String toString() {
		
		String s = "";
		s += "[판매자정보]\n";
		s += "ID : %s\n";
		s += "PW : ********\n";
		s += "이름 : %s\n";
		s += "가게이름 : %s\n";
		
		// String배열로 하니까 에러남 ㅡㅡ 
		Object[] args = {getId(), getName(), store}; 
		return String.format(s, args);
	}
}

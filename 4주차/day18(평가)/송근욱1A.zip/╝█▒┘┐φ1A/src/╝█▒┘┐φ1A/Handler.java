package 송근욱1A;

import java.util.Arrays;
import java.util.Comparator;

public class Handler {
	
	// 정렬 기준 : id 오름차순
	// a와 b중 하나라도 null이면 바꾸지 않는다. / a와 b모두 null이 아니면 비교 후 오름차순으로 정렬한다.
	private Comparator<Member> comp = (a, b) -> a!=null && b!=null ? a.getId().compareTo(b.getId()) : 0;

	private int size = 100;
	private Member[] arr = new Member[size];

	// id의 중복이 없다면 참을, 중복이 있다면 거짓을 반환하는 함수
	private boolean idCheck(String id) {		
		for(Member acc : arr) {
			// acc.id와 id가 동일하다면
			if(acc!=null && acc.getId().equals(id)) {
				return false;	// false를 반환
			}
		}
		return true;
	}
	
	// 입력 ( 회원가입 )
	public int insert(Member member) {
		int row = 0;		// 성공 여부를 출력할 정수
		
		for(int i = 0; i < size; i++) {
			if(arr[i]==null && idCheck(member.getId())) { // 빈 공간을 찾아서
				arr[i] = member;	// 매개변수로 받은 값을 채워 준다 
				row+=1;				// 입력에 성공 : row+=1
				break;
			}
		}
		return row;
	}

	// 전체 목록 반환
	public Member[] selectAll() {
		return arr;	// 전체 목록 반환
	}

	// 제거 ( 회원 탈퇴 )
	public int delete(String id) {
		int row = 0;
		
		for (int i = 0; i < size; i++) {
			if(arr[i] != null && arr[i].getId().equals(id)) {	// 동일한 아이디가 존재한다면
				arr[i] = null;	// 해당 계정 제거
				row += 1;		// 제거 성공 : 1
				break;			// 아이디는 고유하기 때문에 하나를 찾았다면 반복종료
			}
		} 
		
		return row;
	}

	// 단일 검색
	public Member selectOne(String id) {
		Member tmp = null;		// 아이디가 일치하는 계정을 담을 임시 변수
		
		for(int i = 0; i < size; i++) {
			if(arr[i] != null && arr[i].getId().equals(id)) { // 동일한 아이디가 존재한다면
				tmp = arr[i];	// tmp에 해당 계정 대입
				break;			// 아이디는 고유하기 때문에 하나를 찾았다면 반복종료
			}
		}
		
		return tmp; // 찾지 못했다면 null이 반환된다
	}

	// 정렬	
	public Member[] sort() {
		
		/* private Comparator<Member> comp = (a, b) -> a!=null && b!=null ? a.getId().compareTo(b.getId()) : 0; */

		// id순으로 오름차순 
		Arrays.sort(arr, comp);
		
		// 정렬된 배열을 반환
		return arr;
	}
}
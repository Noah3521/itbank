package 송근욱1A;

public class Customer extends Member{
	private String address; 
	public Customer(String id, String pw, String name, String address) {
		super(id, pw, name);
		this.address = address;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		
		String s = "";
		s += "[구매자정보]\n";
		s += "ID : %s\n";
		s += "PW : ********\n";
		s += "이름 : %s\n";
		s += "배송주소 : %s\n";
		
		// String배열로 하니까 에러남 ㅡㅡ 
		Object[] args = {getId(), getName(), address}; 
		return String.format(s, args);
	}
}
